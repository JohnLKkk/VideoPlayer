
#include "encode_video.h"


bool VideoEncoder::isTransform() {
    return transform;
}
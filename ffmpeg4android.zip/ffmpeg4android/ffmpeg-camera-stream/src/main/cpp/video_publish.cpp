
#include "video_publish.h"


bool VideoPublisher::isTransform() {
    return transform;
}
for arch in armeabi-v7a arm64-v8a
do
    bash build_ffmpeg_merge.sh $arch
done
